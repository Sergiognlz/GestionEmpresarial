﻿using ListadoPersonasCRUD.Domain.Entities;

namespace ListadoPersonasCRUD.Domain.DTOs
{
    public class PersonaDepDTO
    {
        public Persona IdPersona { get; }
        public String NDepartamento { get; }

        public PersonaDepDTO(Persona idPersona, String nDepartamento)
        {
            IdPersona = idPersona;
            NDepartamento = nDepartamento;
        }

    }
}

﻿namespace ListadoPersonasCRUD.Domain.Entities
{
    public class Departamento
    {
        public int ID { get; set; }
        public string Nombre { get; set; }



        // Constructor vacío necesario para Model Binding
        public Departamento() { }

        public Departamento(int id, string nombre)
        {
            ID = id;
            Nombre = nombre;
        }

        public Departamento(string nombre)
        {
            Nombre = nombre;
        }
    }
}

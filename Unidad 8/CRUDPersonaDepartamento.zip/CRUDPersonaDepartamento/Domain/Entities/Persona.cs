﻿using System;

namespace ListadoPersonasCRUD.Domain.Entities
{
    public class Persona
    {
        public int ID { get; }
        public string Nombre { get; set; }
        public string Apellidos { get; set; }

        public string Telefono { get; set; }

        public string Direccion { get; set; }

        public string Foto { get; set; }
        public DateTime FechaNacimiento { get; }
     
        public int? IDDepartamento { get; set; }



        public Persona() { }

        public Persona(int id, string nombre, string apellidos, DateTime fechaNacimiento, string direccion, string foto, string telefono, int? departamentoId = null)
        {
            ID = id;
            Nombre = nombre;
            Apellidos = apellidos;
            FechaNacimiento = fechaNacimiento;
            Direccion = direccion;
            Foto= foto;
            Telefono = telefono;
            IDDepartamento = departamentoId;
        }
    }
}
﻿using Microsoft.AspNetCore.Mvc;
using ListadoPersonasCRUD.Domain.UseCasesInterfaces;
using ListadoPersonasCRUD.Domain.Entities;
using ListadoPersonasCRUD.UI.ViewModels;
using System.Linq;

namespace ListadoPersonasCRUD.UI.Controllers
{
    public class DepartamentoController : Controller
    {
        private readonly IDepartamentoUseCase _departamentoUseCase;

        public DepartamentoController(IDepartamentoUseCase departamentoUseCase)
        {
            _departamentoUseCase = departamentoUseCase;
        }

        // GET: /Departamento/
        public IActionResult Index()
        {
            var list = _departamentoUseCase.GetListadoDepartamento();

            var vmList = list.Select(d => new DepartamentoSeleccionadoViewModel
            {
                Id = d.ID,
                Nombre = d.Nombre
            }).ToList();

            return View(vmList);
        }

        // GET: /Departamento/Details/5
        public IActionResult Details(int id)
        {
            var d = _departamentoUseCase.GetDepartamentoById(id);
            if (d == null) return NotFound();

            var vm = new DepartamentoSeleccionadoViewModel
            {
                Id = d.ID,
                Nombre = d.Nombre
            };

            return View(vm); // Asegúrate de que la vista espera DepartamentoSeleccionadoViewModel
        }

        // GET: /Departamento/Create
        public IActionResult Create()
        {
            ViewBag.Titulo = "Crear Departamento";
            return View(new DepartamentoSeleccionadoViewModel());
        }

        // POST: /Departamento/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(DepartamentoSeleccionadoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Titulo = "Crear Departamento";
                return View(model);
            }

            var departamento = new Departamento(model.Nombre);
            _departamentoUseCase.CreateDepartamento(departamento);

            return RedirectToAction(nameof(Index));
        }

        // GET: /Departamento/Edit/5
        public IActionResult Edit(int id)
        {
            var d = _departamentoUseCase.GetDepartamentoById(id);
            if (d == null) return NotFound();

            ViewBag.Titulo = "Editar Departamento";

            var vm = new DepartamentoSeleccionadoViewModel
            {
                Id = d.ID,
                Nombre = d.Nombre
            };

            return View(vm);
        }

        // POST: /Departamento/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(DepartamentoSeleccionadoViewModel model)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Titulo = "Editar Departamento";
                return View(model);
            }

            var departamento = new Departamento(model.Id, model.Nombre);
            _departamentoUseCase.EditDepartamento(departamento);

            return RedirectToAction(nameof(Index));
        }

        // GET: /Departamento/Delete/5
        public IActionResult Delete(int id)
        {
            var d = _departamentoUseCase.GetDepartamentoById(id);
            if (d == null) return NotFound();

            ViewBag.Titulo = "Eliminar Departamento";

            var vm = new DepartamentoSeleccionadoViewModel
            {
                Id = d.ID,
                Nombre = d.Nombre
            };

            return View(vm);
        }

        // POST: /Departamento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                _departamentoUseCase.DeleteDepartamento(id);
                return RedirectToAction(nameof(Index));
            }
            catch (InvalidOperationException ex)
            {
                TempData["Error"] = ex.Message;
                return RedirectToAction(nameof(Details), new { id });
            }
        }
    }
}

﻿using ListadoPersonasCRUD.Domain.DTOs;
using ListadoPersonasCRUD.Domain.Entities;
using ListadoPersonasCRUD.Domain.UseCasesInterfaces;
using ListadoPersonasCRUD.UI.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;

namespace ListadoPersonasCRUD.UI.Controllers
{
    public class PersonaController : Controller
    {
        private readonly IPersonaUseCase _personaUseCase;
        private readonly IDepartamentoUseCase _departamentoUseCase;

        public PersonaController(IPersonaUseCase personaUseCase, IDepartamentoUseCase departamentoUseCase)
        {
            _personaUseCase = personaUseCase;
            _departamentoUseCase = departamentoUseCase;
        }

        // GET: /Persona/
        public IActionResult Index()
        {
            var listado = _personaUseCase.GetListadoPersonas();
            var vmList = listado.Select(p => new PersonaSeleccionadaViewModel
            {
                Id = p.ID,
                Nombre = p.Nombre,
                Apellido = p.Apellidos,
                FechaNacimiento = p.FechaNacimiento,
                Direccion = p.Direccion,
                Telefono = p.Telefono,
                Foto = p.Foto,
                DepartamentoId = p.IDDepartamento
            }).ToList();

            return View(vmList);
        }

        // GET: /Persona/Details/5
        public IActionResult Details(int id)
        {
            var p = _personaUseCase.GetPersonaById(id);
            if (p == null) return NotFound();

            var vm = new PersonaSeleccionadaViewModel
            {
                Id = p.ID,
                Nombre = p.Nombre,
                Apellido = p.Apellidos,
                FechaNacimiento = p.FechaNacimiento,
                Direccion = p.Direccion,
                Telefono = p.Telefono,
                Foto = p.Foto,
                DepartamentoId = p.IDDepartamento
            };

            return View(vm);
        }

        // GET: /Persona/Create
        public IActionResult Create()
        {
            var model = new PersonaSeleccionadaViewModel
            {
                Departamentos = _departamentoUseCase.GetListadoDepartamento() ?? new List<Departamento>()
            };
            return View(model);
        }

        // POST: /Persona/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(PersonaSeleccionadaViewModel model)
        {
            if (!ModelState.IsValid)
            {
                // volver a cargar los departamentos
                model.Departamentos = _departamentoUseCase.GetListadoDepartamento() ?? new List<Departamento>();
                return View(model);
            }

            var persona = new Persona(
                id: 0,
                nombre: model.Nombre,
                apellidos: model.Apellido,
                fechaNacimiento: model.FechaNacimiento,
                direccion: model.Direccion,
                foto: model.Foto,
                telefono: model.Telefono,
                departamentoId: model.DepartamentoId
            );

            _personaUseCase.CreatePersona(persona);
            return RedirectToAction(nameof(Index));
        }


        // GET: /Persona/Edit/5
        public IActionResult Edit(int id)
        {
            var p = _personaUseCase.GetPersonaById(id);
            if (p == null) return NotFound();

            var vm = new PersonaSeleccionadaViewModel
            {
                Id = p.ID,
                Nombre = p.Nombre,
                Apellido = p.Apellidos,
                FechaNacimiento = p.FechaNacimiento,
                Direccion = p.Direccion,
                Telefono = p.Telefono,
                Foto = p.Foto,
                DepartamentoId = p.IDDepartamento,
                Departamentos = _departamentoUseCase.GetListadoDepartamento() ?? new List<Departamento>()
            };

            return View(vm);
        }

        // POST: /Persona/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(PersonaSeleccionadaViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model.Departamentos = _departamentoUseCase.GetListadoDepartamento() ?? new List<Departamento>();
                return View(model);
            }

            var persona = new Persona(
                id: model.Id,
                nombre: model.Nombre,
                apellidos: model.Apellido,
                fechaNacimiento: model.FechaNacimiento,
                direccion: model.Direccion,
                foto: model.Foto,
                telefono: model.Telefono,
                departamentoId: model.DepartamentoId
            );

            _personaUseCase.EditPersona(persona);
            return RedirectToAction(nameof(Index));
        }

        // GET: /Persona/Delete/5
        public IActionResult Delete(int id)
        {
            var p = _personaUseCase.GetPersonaById(id);
            if (p == null) return NotFound();

            var vm = new PersonaSeleccionadaViewModel
            {
                Id = p.ID,
                Nombre = p.Nombre,
                Apellido = p.Apellidos,
                FechaNacimiento = p.FechaNacimiento,
                Direccion = p.Direccion,
                Telefono = p.Telefono,
                Foto = p.Foto,
                DepartamentoId = p.IDDepartamento
            };

            return View(vm);
        }

        // POST: /Persona/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            _personaUseCase.DeletePersona(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
